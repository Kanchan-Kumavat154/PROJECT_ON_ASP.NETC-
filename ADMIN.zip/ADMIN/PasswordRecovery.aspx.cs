﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class ADMIN_PasswordRecovery : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString"].ConnectionString.ToString());
    void PasswordRecovery()
    {
        if (txtnewpasswd.Text != txtconfirmpasswd.Text)
        {
            lblError.Text = "New password and confirm password do not match.";
            error.Style.Add("display", "block");
            return;
        }
        SqlCommand cmd = new SqlCommand("PasswordRecovery", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@newpassword", txtnewpasswd.Text).DbType = DbType.String;
        cmd.Parameters.AddWithValue("@username", txtuname.Text).DbType = DbType.String;
        con.Open();
        int rowsAffected = cmd.ExecuteNonQuery();
        if (rowsAffected > 0)
        {
            //Response.Write("Password changed successfully.");

            lblSuccess.Text = "Password changed successfully.";
            success.Style.Add("display", "block");

        }
        else
        {
            // Response.Write("Failed to change password. Please check your old password.");
            lblSuccess.Text = "Failed to change password. Please check your old password.";
            success.Style.Add("display", "block");
        }
        con.Close();


    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnchangepassword_Click(object sender, EventArgs e)
    {
        PasswordRecovery();
    }
}