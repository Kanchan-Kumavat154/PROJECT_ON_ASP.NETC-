﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class ADMIN_Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString"].ConnectionString.ToString());
    void AdminLogin()
    {
        SqlCommand cmd = new SqlCommand("CheckAdmin", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@username", txtuname.Text).DbType = DbType.String;
        cmd.Parameters.AddWithValue("@password", txtpasswd.Text).DbType = DbType.String;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            Session["UserID"] = ds.Tables[0].Rows[0]["userid"].ToString();
            Response.Redirect("DASHBOARD1.aspx");
        }

    }
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        AdminLogin();
    }
}