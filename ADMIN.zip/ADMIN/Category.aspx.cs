﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class ADMIN_Category : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            Response.Redirect("Default.aspx");
        }
    }
    private void CloseMessages()
    {
        error.Style.Add("display", "none");
        attention.Style.Add("display", "none");
        info.Style.Add("display", "none");
        success.Style.Add("display", "none");
    }

    protected void SqlDataSource1_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {
        FileUpload fa = (FileUpload)FormView1.FindControl("fuImage");
        if (fa.HasFile)
        {
            string strfilename = fa.FileName;
            string ext = System.IO.Path.GetExtension(fa.PostedFile.FileName);
            string name = System.IO.Path.GetFileNameWithoutExtension(fa.PostedFile.FileName);
            if (ext == ".jpg" || ext == ".JPG" || ext == ".JPEG" || ext == ".jpeg" || ext == ".PNG" || ext == ".png")
            {
                String strguid = Guid.NewGuid().ToString();
                String savefilename = Server.MapPath("~/CategoryPhoto/") + name + strguid + ext;
                String strname = "CategoryPhoto/" + name + strguid + ext;
                fa.SaveAs(savefilename);
                e.Command.Parameters["@coverphoto"].Value = strname;
                {
                    // Category already exists
                    e.Cancel = true;
                    CloseMessages();
                    lblError.Text = "Category already exists.";
                    error.Style.Add("display", "block");
                }
            }
            else
            {
                e.Cancel = true;
            }
        }
    }

  
    protected void FormView1_ItemInserted1(object sender, FormViewInsertedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GridView1.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record Inserted Successfully";
            success.Style.Add("display","block");
        }
    }
    protected void GridView1_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GridView1.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record Deleted Successfully";
            success.Style.Add("display", "block");
        }
    }
    protected void FormView1_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GridView1.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record Updated Successfully";
            success.Style.Add("display", "block");
        }
    }
    protected void SqlDataSource1_Updating(object sender, SqlDataSourceCommandEventArgs e)
    {
        FileUpload fa = (FileUpload)FormView1.FindControl("fuImage");
        if (fa.HasFile)
        {
            string strfilename = fa.FileName;
            string ext = System.IO.Path.GetExtension(fa.PostedFile.FileName);
            string name = System.IO.Path.GetFileNameWithoutExtension(fa.PostedFile.FileName);
            if (ext == ".jpg" || ext == ".JPG" || ext == ".JPEG" || ext == ".jpeg" || ext == ".PNG" || ext == ".png")
            {
                String strguid = Guid.NewGuid().ToString();
                String savefilename = Server.MapPath("~/CategoryPhoto/") + name + strguid + ext;
                String strname = "CategoryPhoto/" + name + strguid + ext;
                fa.SaveAs(savefilename);
                e.Command.Parameters["@coverphoto"].Value = strname;
            }
            else
            {
                e.Cancel = true;
            }
        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        FormView1.DataBind();
        FormView1.ChangeMode(FormViewMode.Edit);   
    }
    // Method to check if product exists in the database
    // Method to check if category exists in the database
    private bool CategoryExists(string categoryName)
    {
        bool exists = false;
        using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString"].ConnectionString))
        {
            using (SqlCommand cmd = new SqlCommand("CheckExistCategory", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@categoryname", categoryName).DbType = DbType.String;
                con.Open();
                exists = Convert.ToBoolean(cmd.ExecuteScalar());
            }
        }
        return exists;
    }
}