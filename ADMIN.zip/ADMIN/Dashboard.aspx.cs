﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class ADMIN_Dashboard : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString"].ConnectionString.ToString());
    void CategoryCount()
    {
        SqlCommand cmd = new SqlCommand("DashboardCountForCategory", con);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            Label1.Text = ds.Tables[0].Rows[0]["Name"].ToString();
            Label2.Text = ds.Tables[0].Rows[0]["Total"].ToString();
            
        }
    }

    void SubCategoryCount()
    {
        SqlCommand cmd = new SqlCommand("DashboardCountForSubCategory", con);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            Label3.Text = ds.Tables[0].Rows[0]["Name"].ToString();
            Label4.Text = ds.Tables[0].Rows[0]["Total"].ToString();

        }
    }

    void ProductCount()
    {
        SqlCommand cmd = new SqlCommand("DashboardCountForProduct", con);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            Label5.Text = ds.Tables[0].Rows[0]["Name"].ToString();
            Label6.Text = ds.Tables[0].Rows[0]["Total"].ToString();

        }
    }

    void OrderCount()
    {
        SqlCommand cmd = new SqlCommand("DashboardCountForOrder", con);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            Label7.Text = ds.Tables[0].Rows[0]["Name"].ToString();
            Label8.Text = ds.Tables[0].Rows[0]["Total"].ToString();

        }
    }

    void UserCount()
    {
        SqlCommand cmd = new SqlCommand("DashboardCountForUser", con);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            Label9.Text = ds.Tables[0].Rows[0]["Name"].ToString();
            Label10.Text = ds.Tables[0].Rows[0]["Total"].ToString();

        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        CategoryCount();
        SubCategoryCount();
        ProductCount();
        OrderCount();
        UserCount();
    }
}