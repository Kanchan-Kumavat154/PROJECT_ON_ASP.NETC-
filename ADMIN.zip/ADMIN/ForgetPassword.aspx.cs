﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Net.Mail;
using System.Net;

using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class ADMIN_ForgetPassword : System.Web.UI.Page
{
      SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString"].ConnectionString.ToString());
      void ForgetPassword()
      {
          SqlCommand cmd = new SqlCommand("CheckAdminMail", con);
          cmd.CommandType = CommandType.StoredProcedure;
          cmd.Parameters.AddWithValue("@EmailID", txtemail.Text).DbType = DbType.String;
          //cmd.Parameters.AddWithValue("@password", Session["Password"]).DbType = DbType.String;
          con.Open();
          SqlDataReader reader = cmd.ExecuteReader();

          if (reader.Read()) // If there's a row returned from the database
          {
              string dbEmail = reader["EmailID"].ToString(); // Replace "EmailColumn" with the actual column name in your database
              if (string.Equals(dbEmail, txtemail.Text, StringComparison.OrdinalIgnoreCase))
              {
                  Response.Write("<script>alert('Email matched successfully.')</script>");
                  Session["Password"] = reader["password"].ToString();
                  SendEmail();
              }
              else
              {
                  Response.Write("<script>alert('Email does not match.')</script>");
              }
          }
          else
          {
              Response.Write("<script>alert('Email does not exist.')</script>");
          }

          reader.Close();
          con.Close();
      }

    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void btnemail_Click(object sender, EventArgs e)
    {
        ForgetPassword();
        //SendEmail();
    }
    private void SendEmail()
    {
        string senderEmail = "twebsite32@gmail.com";
        string senderPassword = "sgljvaiysrviewmp";

        // Receiver's email address here you can pass Receiver mail id to whom you want to send an email
        string receiverEmail = txtemail.Text;

        // SMTP server details
        string smtpServer = "smtp.gmail.com"; // Assuming you are using Gmail SMTP server
        int smtpPort = 587; // Port for TLS

        // Create a new SMTP client using SmtpClinet
        SmtpClient smtpClient = new SmtpClient(smtpServer, smtpPort);
        smtpClient.EnableSsl = true; // Enable SSL/TLS encryption

        // Here you need to set credentials (sender's email address and password)
        smtpClient.Credentials = new NetworkCredential(senderEmail, senderPassword);

        //Here you can Create a new MailMessage object
        MailMessage mailMessage = new MailMessage(senderEmail, receiverEmail);

        //Here you can Set email subject and body
        mailMessage.Subject = "Test Email";
        mailMessage.Body = " Your Password is:"+ Session["Password"] .ToString()+Environment.NewLine+"Login To Continue with your Password.";

        try
        {
            //Now we are ready to send the email
            smtpClient.Send(mailMessage);

            Response.Write("<script> alert('Email sent successfully.') </script>");
        }
        catch (Exception ex)
        {
            // Log error message here incase it is failing
            Response.Write("Failed to send email: " + ex.Message);
        }
    }
}