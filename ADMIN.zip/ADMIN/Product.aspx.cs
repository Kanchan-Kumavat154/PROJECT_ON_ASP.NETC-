﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class ADMIN_Product : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            Response.Redirect("Default.aspx");
        }
    }
    private void CloseMessages()
    {
        error.Style.Add("display", "none");
        attention.Style.Add("display", "none");
        info.Style.Add("display", "none");
        success.Style.Add("display", "none");
    }
    protected void FormView1_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GridView1.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record Inserted Successfully";
            success.Style.Add("display", "block");
        }
    }
    protected void SqlDataSource1_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {

        FileUpload fa = (FileUpload)FormView1.FindControl("fuImage");
        if (fa.HasFile)
        {
            string strfilename = fa.FileName;
            string ext = System.IO.Path.GetExtension(fa.PostedFile.FileName);
            string name = System.IO.Path.GetFileNameWithoutExtension(fa.PostedFile.FileName);
            if (ext == ".jpg" || ext == ".JPG" || ext == ".JPEG" || ext == ".jpeg" || ext == ".PNG" || ext == ".png")
            {
                String strguid = Guid.NewGuid().ToString();
                String savefilename = Server.MapPath("~/ProductImage/") + name + strguid + ext;
                String strname = "ProductImage/" + name + strguid + ext;
                fa.SaveAs(savefilename);
                e.Command.Parameters["@productimage"].Value = strname;
                ExistProduct();
                if (Session["flag"] == "1")
                {
                    e.Cancel = true;
                    CloseMessages();
                    lblError.Text = "Record Exist Already";
                    error.Style.Add("display", "block");
                    Session["flag"] = "0";
                }
                
            }
            else
            {
                e.Cancel = true;
            }
        }

    }
    protected void GridView1_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GridView1.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record Deleted Successfully";
            success.Style.Add("display", "block");
        }
    }
    protected void SqlDataSource1_Updating(object sender, SqlDataSourceCommandEventArgs e)
    {
        FileUpload fa = (FileUpload)FormView1.FindControl("fuImage");
        if (fa.HasFile)
        {
            string strfilename = fa.FileName;
            string ext = System.IO.Path.GetExtension(fa.PostedFile.FileName);
            string name = System.IO.Path.GetFileNameWithoutExtension(fa.PostedFile.FileName);
            if (ext == ".jpg" || ext == ".JPG" || ext == ".JPEG" || ext == ".jpeg" || ext == ".PNG" || ext == ".png")
            {
                String strguid = Guid.NewGuid().ToString();
                String savefilename = Server.MapPath("~/ProductImage/") + name + strguid + ext;
                String strname = "ProductImage/" + name + strguid + ext;
                fa.SaveAs(savefilename);
                e.Command.Parameters["@productimage"].Value = strname;
            }
            else
            {
                e.Cancel = true;
            }
        }
    }
    protected void FormView1_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GridView1.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record Updated Successfully";
            success.Style.Add("display", "block");
        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        FormView1.DataBind();
        FormView1.ChangeMode(FormViewMode.Edit);
    }
    void ExistProduct()
    {
        TextBox productname = (TextBox)FormView1.FindControl("productnameTextBox");
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString"].ConnectionString.ToString());
        SqlCommand cmd = new SqlCommand("CheckExistProduct", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@productname", productname.Text).DbType = DbType.String;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
                Session["flag"] = "1";
        }
    }

}