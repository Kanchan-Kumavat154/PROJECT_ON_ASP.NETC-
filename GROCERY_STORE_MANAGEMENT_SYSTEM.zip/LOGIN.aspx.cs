﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class LOGIN : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString"].ConnectionString.ToString());
    void UserLogin()
    {
        SqlCommand cmd = new SqlCommand("CheckUser", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@MobileNo", txtmobileno.Text).DbType = DbType.String;
        cmd.Parameters.AddWithValue("@Password", txtpasswd.Text).DbType = DbType.String;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            Session["UserID"] = ds.Tables[0].Rows[0]["RegistrationID"].ToString();
            Response.Redirect("ViewAllCategory.aspx");
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    private void CloseMessages()
    {
        error.Style.Add("display", "none");
        attention.Style.Add("display", "none");
        info.Style.Add("display", "none");
        success.Style.Add("display", "none");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        UserLogin();
    }
}