﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;
using System.Configuration;

using System.Net;
using System.Net.Mail;
using System.Diagnostics;

using System.Text;

public partial class ShippingForm : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString"].ConnectionString.ToString());
    void GetOrderNo()
    {
        SqlCommand cmd = new SqlCommand("GetOrderNo", con);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            Session["OrderNo"] = ds.Tables[0].Rows[0]["OrderNo"].ToString();
            //Response.Redirect("ViewAllCategory.aspx");
            OrderMasterInsert();
        }

    }
    void OrderMasterInsert()
    {
        DropDownList dl = (DropDownList)FormView1.FindControl("DropDownList1");
        con.Open();
        SqlCommand cmd = new SqlCommand("OrderMasterInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@OrderNo", Session["OrderNo"]).DbType = DbType.String;
        cmd.Parameters.AddWithValue("@TotalItem", Session["TotalItem"]).DbType = DbType.String;
        cmd.Parameters.AddWithValue("@TotalAmount", Session["TotalAmt"]).DbType = DbType.String;
        cmd.Parameters.AddWithValue("@TotalNetAmount", Session["NetAmt"]).DbType = DbType.String;
        cmd.Parameters.AddWithValue("@PaymentMethod", dl.Text).DbType = DbType.String;
        if (dl.Text == "Online")
        {
            cmd.Parameters.AddWithValue("@PaymentStatus", "True").DbType = DbType.Boolean;

        }
        else
        {
            cmd.Parameters.AddWithValue("@PaymentStatus", "false").DbType = DbType.Boolean;
        }
        cmd.Parameters.AddWithValue("@RegistrationID", Session["UserID"]).DbType = DbType.Int32;
        Session["OrderId"] = cmd.ExecuteScalar().ToString();
        cmd.Dispose();
        con.Close();
        ViewDataFromCart();

    }
    void ViewDataFromCart()
    {
        SqlCommand cmd = new SqlCommand("CartDetailByRegistration", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@RegistrationID", Session["UserID"]).DbType = DbType.String;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
            {
                con.Open();
                SqlCommand cmd1 = new SqlCommand("OrderDetailInsert", con);
                cmd1.CommandType = CommandType.StoredProcedure;
                cmd1.Parameters.AddWithValue("@OrderID", Session["OrderId"]).DbType = DbType.Int32;
                cmd1.Parameters.AddWithValue("@productid", ds.Tables[0].Rows[i]["productid"]).DbType = DbType.Int32;
                cmd1.Parameters.AddWithValue("@mrp", ds.Tables[0].Rows[i]["mrp"]).DbType = DbType.Int32;
                cmd1.ExecuteNonQuery();
                cmd1.Dispose();
                con.Close();
            }
            DeleteCart();
        }
    }
    void DeleteCart()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("DeleteRegistrationCart", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@RegistrationID", Session["UserID"]).DbType = DbType.String;
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        con.Close();
        SendEmail();
        Response.Redirect("Thankyou.aspx");
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            Response.Redirect("LOGIN.aspx");
        }
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        GetOrderNo();
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label cd = (Label)FormView1.FindControl("Label2");
        Label em = (Label)FormView1.FindControl("Label3");
        Label ey = (Label)FormView1.FindControl("Label4");
        Label cv = (Label)FormView1.FindControl("Label5");
        Label ch = (Label)FormView1.FindControl("Label6");

        TextBox tcd = (TextBox)FormView1.FindControl("CardNoTextBox");
        TextBox tem = (TextBox)FormView1.FindControl("ExpiryMonthTextBox");
        TextBox tey = (TextBox)FormView1.FindControl("ExpiryYearTextBox");
        TextBox tcv = (TextBox)FormView1.FindControl("CVVNoTextBox");
        TextBox tch = (TextBox)FormView1.FindControl("CardHolderNameTextBox");

        DropDownList pm = (DropDownList)FormView1.FindControl("DropDownList1");
        if (pm.Text == "Online")
        {
            cd.Visible = true;
            em.Visible = true;
            ey.Visible = true;
            cv.Visible = true;
            ch.Visible = true;

            tcd.Visible = true;
            tem.Visible = true;
            tey.Visible = true;
            tcv.Visible = true;
            tch.Visible = true;
        }
        else
        {
            cd.Visible = false;
            em.Visible = false;
            ey.Visible = false;
            cv.Visible = false;
            ch.Visible = false;

            tcd.Visible = false;
            tem.Visible = false;
            tey.Visible = false;
            tcv.Visible = false;
            tch.Visible = false;
        }


    }
    protected void FormView1_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        try
        {
            GetOrderNo();
        }
        catch (Exception ex)
        {
        }

    }

    private void SendEmail()
    {
        TextBox txtmail = (TextBox)FormView1.FindControl("EmailIDTextBox");
        string senderEmail = "twebsite32@gmail.com";
        string senderPassword = "sgljvaiysrviewmp";

        // Receiver's email address
        string receiverEmail = txtmail.Text; // Assuming there's a TextBox named txtmail for entering email

        // SMTP server details
        string smtpServer = "smtp.gmail.com"; // Assuming you are using Gmail SMTP server
        int smtpPort = 587; // Port for TLS

        // Create a new SMTP client using SmtpClient
        SmtpClient smtpClient = new SmtpClient(smtpServer, smtpPort);
        smtpClient.EnableSsl = true; // Enable SSL/TLS encryption

        // Set sender's credentials
        smtpClient.Credentials = new NetworkCredential(senderEmail, senderPassword);

        // Create a new MailMessage object
        MailMessage mailMessage = new MailMessage(senderEmail, receiverEmail);

        // Set email subject
        mailMessage.Subject = "Thank You For Visiting Our Shop.... Customer Bill Details";

        try
        {
            // Retrieve data from the database
            int registrationID = Convert.ToInt32(Session["UserID"]);
            long orderID = Convert.ToInt64(Session["OrderId"]); // Assuming Session["OrderId"] holds the OrderID

            // Debug information
            Debug.WriteLine("Registration ID: " + registrationID + ", Order ID: " + orderID);

            // Retrieve data from the database
            DataTable dt = GetCustomerBillData(registrationID, orderID); // Pass both arguments

            // Construct the email body with HTML content including the data in tables
            StringBuilder emailBody = new StringBuilder();
            emailBody.AppendLine("<h2 style='color: #333; font-family: Arial, sans-serif;'>Customer Bill Details</h2>");

            // Table for order details
            emailBody.AppendLine("<table style='border-collapse: collapse; width: 100%;' border='1'>");
            emailBody.AppendLine("<tr style='background-color: #f2f2f2;'>");
            emailBody.AppendLine("<th style='padding: 8px; text-align: left;'>Order Date</th>");
            emailBody.AppendLine("<th style='padding: 8px; text-align: left;'>Total Items</th>");
            emailBody.AppendLine("<th style='padding: 8px; text-align: left;'>Total Amount</th>");
            emailBody.AppendLine("<th style='padding: 8px; text-align: left;'>Total Net Amount</th>");
            emailBody.AppendLine("</tr>");

            // Print order details only once
            DataRow orderRow = dt.Rows[0]; // Assuming there's only one order detail row
            emailBody.AppendLine("<tr>");
            emailBody.AppendLine("<td style='padding: 8px;'>" + Convert.ToDateTime(orderRow["OrderDate"]).ToString("dd-MM-yyyy HH:mm:ss") + "</td>");
            emailBody.AppendLine("<td style='padding: 8px;'>" + orderRow["TotalItem"].ToString() + "</td>");
            emailBody.AppendLine("<td style='padding: 8px;'>" + Convert.ToDecimal(orderRow["TotalAmount"]).ToString("0.00") + "</td>");
            emailBody.AppendLine("<td style='padding: 8px;'>" + Convert.ToDecimal(orderRow["TotalNetAmount"]).ToString("0.00") + "</td>");
            emailBody.AppendLine("</tr>");
            emailBody.AppendLine("</table>");

            // Table for product details
            emailBody.AppendLine("<h2 style='color: #333; font-family: Arial, sans-serif;'>Product Details</h2>");
            emailBody.AppendLine("<table style='border-collapse: collapse; width: 100%;' border='1'>");
            emailBody.AppendLine("<tr style='background-color: #f2f2f2;'>");
            emailBody.AppendLine("<th style='padding: 8px; text-align: left;'>Product Name</th>");
            emailBody.AppendLine("<th style='padding: 8px; text-align: left;'>MRP</th>");
            emailBody.AppendLine("</tr>");

            // Loop through each product and print its details
            foreach (DataRow row in dt.Rows)
            {
                emailBody.AppendLine("<tr>");
                emailBody.AppendLine("<td style='padding: 8px;'>" + row["productname"].ToString() + "</td>");
                emailBody.AppendLine("<td style='padding: 8px;'>" + Convert.ToDecimal(row["mrp"]).ToString("0.00") + "</td>");
                emailBody.AppendLine("</tr>");
            }

            emailBody.AppendLine("</table>");

            mailMessage.Body = emailBody.ToString();
            mailMessage.IsBodyHtml = true; // Set to true to indicate HTML content in the email body

            // Send the email
            smtpClient.Send(mailMessage);

            Response.Write("<script> alert('Email sent successfully.') </script>");
        }
        catch (Exception ex)
        {
            // Log error message here in case it is failing
            Response.Write("Failed to send email: " + ex.Message);
        }
    }

private DataTable GetCustomerBillData(int registrationID, long orderID)
{
    DataTable dt = new DataTable();
    string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString"].ConnectionString;

    using (SqlConnection connection = new SqlConnection(connectionString))
    {
        using (SqlCommand command = new SqlCommand("CustomerBill", connection))
        {
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@RegistrationID", registrationID);
            command.Parameters.AddWithValue("@OrderID", orderID);
            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
            {
                adapter.Fill(dt);
            }
        }
    }

    return dt;
}


}
