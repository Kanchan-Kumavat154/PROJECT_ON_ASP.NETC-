﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class ViewAllCart : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString"].ConnectionString.ToString());
    void CartSummary()
    {
        SqlCommand cmd = new SqlCommand("CartSummary", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@RegistrationID", Session["UserID"]).DbType = DbType.String;
        
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            txtproduct.Text = ds.Tables[0].Rows[0]["TotalItem"].ToString();
            txtamt.Text = ds.Tables[0].Rows[0]["TotalAmt"].ToString();
            txtnamt.Text = ds.Tables[0].Rows[0]["NetAmt"].ToString();
        }

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            Response.Redirect("LOGIN.aspx");
        }
        else {
            CartSummary();
        }
    }

    protected void btncheckout_Click(object sender, EventArgs e)
    {
        Session["TotalItem"] = txtproduct.Text;
        Session["TotalAmt"] = txtamt.Text;
        Session["NetAmt"] = txtnamt.Text;
        Response.Redirect("ShippingForm.aspx");  
    }
}