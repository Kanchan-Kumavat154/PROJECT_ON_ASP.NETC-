﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class WishList : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString"].ConnectionString.ToString());
    void Insert()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("CartDetailInsert", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@RegistrationID", Session["UserID"]).DbType = DbType.String;
            cmd.Parameters.AddWithValue("@productid", Session["productid"]).DbType = DbType.String;
            cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            // Handle any exceptions, if necessary
        }
        finally
        {
            con.Close();
        }
    }
   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            Response.Redirect("LOGIN.aspx");
        }
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        if (Session["UserID"] == null)
        {
            Response.Redirect("LOGIN.aspx");
        }
        else
        {
            ImageButton btn;
            btn = (ImageButton)sender;
            DataListItem dli;
            dli = (DataListItem)btn.NamingContainer;
            Session["productid"] = Convert.ToInt64(DataList1.DataKeys[dli.ItemIndex].ToString());
            Insert();
            Response.Write("<script> alert('Add to Cart Successfully')</script>");
        }
    }

    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
        if (e.CommandName == "Delete")
        {
            // Get the WishListID of the item to be deleted
            int wishListID = Convert.ToInt32(DataList1.DataKeys[e.Item.ItemIndex]);

            // Delete the item from the database
            DeleteWishListItem(wishListID);

            // Rebind the DataList to reflect the changes
            DataList1.DataBind();
        }
    }
    private void DeleteWishListItem(int wishListID)
    {
        // Your logic to delete the item from the database
        // For example, you can execute a delete query using your SqlDataSource
        SqlDataSource1.DeleteParameters["WishListID"].DefaultValue = wishListID.ToString();
        SqlDataSource1.Delete();
    }
}