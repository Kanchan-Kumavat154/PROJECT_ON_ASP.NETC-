﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
using System.Web.UI;

public partial class CustomerViewBill : System.Web.UI.Page
{
    protected void Button1_Click(object sender, EventArgs e)
    {
        SendEmail();
    }

    private void SendEmail()
    {
        string senderEmail = "twebsite32@gmail.com";
        string senderPassword = "sgljvaiysrviewmp";

        // Receiver's email address
        string receiverEmail = txtmail.Text; // Assuming there's a TextBox named txtmail for entering email

        // SMTP server details
        string smtpServer = "smtp.gmail.com"; // Assuming you are using Gmail SMTP server
        int smtpPort = 587; // Port for TLS

        // Create a new SMTP client using SmtpClinet
        SmtpClient smtpClient = new SmtpClient(smtpServer, smtpPort);
        smtpClient.EnableSsl = true; // Enable SSL/TLS encryption

        // Set sender's credentials
        smtpClient.Credentials = new NetworkCredential(senderEmail, senderPassword);

        // Create a new MailMessage object
        MailMessage mailMessage = new MailMessage(senderEmail, receiverEmail);

        // Set email subject
        mailMessage.Subject = "Customer Bill Details";

        // Retrieve data from the database
        int registrationID = Convert.ToInt32(Session["UserID"]);
        DataTable dt = GetCustomerBillData(registrationID);

        // Construct the email body with HTML content including the data in a table
        string emailBody = "<h2>Customer Bill Details</h2>";
        emailBody += "<table border='1'><tr><th>Order Date</th><th>Total Items</th><th>Total Amount</th><th>Total Net Amount</th></tr>";

        foreach (DataRow row in dt.Rows)
        {
            emailBody += "<tr>";
            //emailBody += "<td>" + row["RegistrationID"].ToString() + "</td>";
            //emailBody += "<td>" + row["OrderID"].ToString() + "</td>";
            emailBody += "<td>" + Convert.ToDateTime(row["OrderDate"]).ToString("dd-MM-yyyy HH:mm:ss") + "</td>";
            emailBody += "<td>" + row["TotalItem"].ToString() + "</td>";
            emailBody += "<td>" + Convert.ToDecimal(row["TotalAmount"]).ToString("0.00") + "</td>";
            emailBody += "<td>" + Convert.ToDecimal(row["TotalNetAmount"]).ToString("0.00") + "</td>";
            emailBody += "</tr>";
        }

        emailBody += "</table>";
        mailMessage.Body = emailBody;
        mailMessage.IsBodyHtml = true; // Set to true to indicate HTML content in the email body

        try
        {
            // Send the email
            smtpClient.Send(mailMessage);

            Response.Write("<script> alert('Email sent successfully.') </script>");
        }
        catch (Exception ex)
        {
            // Log error message here in case it is failing
            Response.Write("Failed to send email: " + ex.Message);
        }
    }

    private DataTable GetCustomerBillData(int registrationID)
    {
        DataTable dt = new DataTable();
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString"].ConnectionString;

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            using (SqlCommand command = new SqlCommand("CustomerBill", connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@RegistrationID", registrationID);

                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    adapter.Fill(dt);
                }
            }
        }

        return dt;
    }
}
