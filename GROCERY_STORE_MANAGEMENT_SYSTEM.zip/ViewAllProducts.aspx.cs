﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class ViewAllProducts : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString"].ConnectionString.ToString());
    void Insert()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("CartDetailInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@RegistrationID", Session["UserID"]).DbType = DbType.String;
        cmd.Parameters.AddWithValue("@productid", Session["productid"]).DbType = DbType.String;
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        con.Close();

    }

    void WishListInsert()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("WishListDetailInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@RegistrationID", Session["UserID"]).DbType = DbType.String;
        cmd.Parameters.AddWithValue("@productid", Session["productid"]).DbType = DbType.String;
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        con.Close();

    }
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) {
            if (txtsearch.Text.Trim() != "")
            {
                SqlDataSource1.SelectParameters["productname"].DefaultValue = txtsearch.Text;
            }
            else
            {
                SqlDataSource1.SelectParameters["productname"].DefaultValue = " ";
            }
            SqlDataSource1.DataBind();
            DataList1.DataBind();
        }
    }


    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        if (Session["UserID"] == null)
        {
            Response.Redirect("LOGIN.aspx");
        }
        else
        {
            ImageButton btn;
            btn = (ImageButton)sender;
            DataListItem dli;
            dli = (DataListItem)btn.NamingContainer;
            Session["productid"] = Convert.ToInt64(DataList1.DataKeys[dli.ItemIndex].ToString());
            Insert();
            Response.Write("<script> alert('Add to Cart Successfully')</script>");
        }
    }

    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        if (Session["UserID"] == null)
        {
            Response.Redirect("LOGIN.aspx");
        }
        else
        {
            ImageButton btn;
            btn = (ImageButton)sender;
            DataListItem dli;
            dli = (DataListItem)btn.NamingContainer;
            Session["productid"] = Convert.ToInt64(DataList1.DataKeys[dli.ItemIndex].ToString());
            WishListInsert();
        }
    }
    //protected void btnsearch_Click(object sender, EventArgs e)
    //{
    //    if (txtsearch.Text.Trim() != "")
    //        SqlDataSource1.SelectParameters["productname"].DefaultValue = txtsearch.Text;
    //    else 
    //        SqlDataSource1.SelectParameters["productname"].DefaultValue = " ";

    //    SqlDataSource1.DataBind();
    //    DataList1.DataBind();
    //}
    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        if (txtsearch.Text.Trim() != "")
            SqlDataSource1.SelectParameters["productname"].DefaultValue = txtsearch.Text;
        else
            SqlDataSource1.SelectParameters["productname"].DefaultValue = " ";

        SqlDataSource1.DataBind();
        DataList1.DataBind();
    }
}