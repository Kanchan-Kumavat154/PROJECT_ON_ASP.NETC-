﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UserProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Session["UserID"] != null)
        //{
        //    Label8.Text = Session["UserID"].ToString();
        //}
        //else
        //{
        //    // Handle the case where Session["UserID"] is null
        //    // For example, you might set a default value or display an error message
        //    Label8.Text = "User ID not available";
        //}
        if (Session["UserID"] == null)
        {
                Response.Redirect("LOGIN.aspx");
        }

    }

    protected void btnLogOut_Click(object sender, EventArgs e)
    {
        Response.Redirect("LOGIN.aspx");
    }



  
    protected void FormView2_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {
        Label8.Text = "Data updated Successfully";
        FormView2.DataBind();
    }
}